---@type DP
local dp = _DP
---@type DPXGame
local dpx = _DPX

local game = require("df.game")
local logger = require("df.logger")

logger.info("opt: %s", dpx.opt())

-- see dp2/lua/df/doc for document !
